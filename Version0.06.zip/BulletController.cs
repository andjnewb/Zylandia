﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class BulletController : MonoBehaviour
{
    // Start is called before the first frame update
    public float distance;


    void Start()
    {
        StartCoroutine(DestroyBullet(10.0f));
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    IEnumerator DestroyBullet(float waitTime)
    {
        while (true)
        {

            yield return new WaitForSeconds(waitTime);
            Destroy(gameObject);

        }
    }



    public void OnTriggerEnter(Collider other)
    {
        //Debug.Log(other.name);
        if (other.name != "45ACP Bullet_Head")
        {
            //Destroy(gameObject);
        }
        other.SendMessage("TakeDamage", 15, SendMessageOptions.DontRequireReceiver );
        
        
    }
}
