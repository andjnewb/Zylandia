﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    Ray playerLook;//A ray for object interaction.
    RaycastHit playerLookHit;

    void Start()
    {
        //Cast a ray to wherever the mouse currently is
        playerLook = GetComponent<Camera>().ScreenPointToRay(Input.mousePosition);
        //Debug.Log(playerLook);
        
        
        
    }

    // Update is called once per frame
    void Update()
    {
        


        if (Physics.Raycast(playerLook, out playerLookHit))
        {
            if (playerLookHit.collider.name == "Zombie_Ready(Clone)")
            {
                Debug.Log("Cheese");
            }



            //set the spawn object to aim here

           
        }
        

    }
}
