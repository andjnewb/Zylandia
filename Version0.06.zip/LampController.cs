﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LampController : MonoBehaviour
{
    // Just a test interactable

    public void interact()
    {
        Debug.Log("Player interacted with me");

        GetComponent<Light>().enabled = !GetComponent<Light>().enabled;
    }


}
