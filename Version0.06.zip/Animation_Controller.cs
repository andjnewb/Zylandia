﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Animation_Controller : MonoBehaviour
{

    Animator animator;


    public anims animations = anims.Idle;

    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (animations == anims.Run)
        {
            animator.SetBool("run", true);
            animator.SetBool("idle", false);
            animator.SetBool("attack", false);
        }

        if (animations == anims.Idle)
        {
            animator.SetBool("idle", true);
            animator.SetBool("run", false);
            animator.SetBool("attack", false);
        }

        if (animations == anims.Attack)
        {
            animator.SetBool("attack", true);
            animator.SetBool("run", false);
            animator.SetBool("idle", false);
        }
        else 
        {
            animator.SetBool("attack", false);
        }
        
    }
}
public enum anims
{
    Idle,
    Run,
    Attack

}
