﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HandController : MonoBehaviour
{
    RaycastHit hit;

    
    // Start is called before the first frame update
    void Start()
    {
       // Debug.DrawLine(transform.position, new Vector3(5, 0, 0), Color.red);
        
    }

    // Update is called once per frame
    void Update()
    {

        //Debug.Log(transform.position);
        //Debug.DrawLine(transform.position, Vector3.up, Color.red);
    }

    public void FixedUpdate()
    {

        
    }

    
}
