﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hitmarker : MonoBehaviour
{
    // Start is called before the first frame update

    void Start()
    {
        StartCoroutine(MarkerWait(3.08f));
        gameObject.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public IEnumerator MarkerWait(float waitTime)
    {
        while (true)
        {

            
            yield return new WaitForSeconds(waitTime);
            gameObject.SetActive(false);



        }
    }

    
}
