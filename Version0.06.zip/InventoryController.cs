﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InventoryController : MonoBehaviour
{

    public int selectedWeapon = 0;
    public bool[] itemIsInInventory = new bool[10];

    void Start()
    {
        itemIsInInventory[0] = true;//pistol
        itemIsInInventory[1] = false;//machine gun
        itemIsInInventory[2] = true;
        SelectWeapon();


    }

    // Update is called once per frame
    void Update()
    {
        int previousSelectedWeapon = selectedWeapon;

        

        //We select the weapon with the scroll wheel
        if (Input.GetAxis("Mouse ScrollWheel") > 0.0f)
        {
            

            if (selectedWeapon >= transform.childCount - 1)
            {
                selectedWeapon = 0;
            }
            else {
                selectedWeapon++;
            }

            if (Input.GetAxis("Mouse ScrollWheel") < 0.0f)
            {

                if (selectedWeapon <= 0)
                {
                    selectedWeapon = transform.childCount - 1;
                }
                else
                {
                    selectedWeapon--;
                }


            }

        }

        if (previousSelectedWeapon != selectedWeapon)
        {
            SelectWeapon();
        }


    }

    void SelectWeapon()
    {
        //Loop through all children of the inventory object, enabling the currently selected one and disabling the rest.

        int i = 0;
        foreach (Transform weapon in transform)
        {
            if (i == selectedWeapon)
            {
                //Debug.Log(itemIsInInventory[i]);
                

                if(itemIsInInventory[selectedWeapon])
                    weapon.gameObject.SetActive(true);

            }
            else {
                weapon.gameObject.SetActive(false);
            }


            i++;
        }
    }
    
}
