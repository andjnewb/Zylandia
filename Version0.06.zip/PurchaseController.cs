﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PurchaseController : MonoBehaviour
{
    public int itemCost = 500;
    public GameObject playerInventory;
    public GameObject player;
    public string type;


    public string InteractionText;

    public void enableForPlayer()
    {

        if(type == "mg")
        {
            playerInventory.GetComponent<InventoryController>().itemIsInInventory[1] = true;
            player.GetComponent<PlayerController>().playerCredits -= itemCost;
        }

        if (type == "hp")
        {
            player.GetComponent<PlayerController>().health = 100;
            player.GetComponent<PlayerController>().playerCredits -= itemCost;
        }

    }

    public void Update()
    {
        
    }
}
