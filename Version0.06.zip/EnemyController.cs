﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyController : MonoBehaviour
{

    public GameObject[] target;

    public Animation_Controller controller;
    public int health = 100;

    NavMeshAgent agent;

    public GameObject pSystem;
    public GameObject giblets;//not working

    RaycastHit rayHit = new RaycastHit();
    Ray ray = new Ray();//not used

    public Canvas ui;


    // Start is called before the first frame update
    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        controller = GetComponent<Animation_Controller>();
        agent.angularSpeed *= 10 * Time.deltaTime;
        agent.stoppingDistance = 2.0f;
        ray = new Ray(transform.position, target[0].transform.position);


        if (pSystem == null)
        {
            Debug.Log("Jew");
        }
        StartCoroutine(AttackWait(2.0f));

    }

    // Update is called once per frame
    void Update()
    {



    }

    public void FixedUpdate()
    {
        target[0] = GameObject.FindGameObjectWithTag("Player");
        transform.LookAt(new Vector3(target[0].transform.position.x, 0, target[0].transform.position.z));
        float dist = Vector3.Distance(transform.position, target[0].transform.position);

        //Debug.Log(dist);
        if (health <= 0)
        {
            Instantiate(giblets,this.transform);
            Destroy(this.gameObject);
            GetComponentInParent<GameManager>().zombieCount--;
            target[0].GetComponent<PlayerController>().playerCredits += 100;

        }

        if (dist > agent.stoppingDistance)
        {
            controller.animations = anims.Run;
            agent.destination = target[0].transform.position;
        }


        Debug.DrawLine(transform.position, rayHit.point, Color.red);
        //Debug.Log(rayHit.collider.transform.position);
    }

    IEnumerator AttackWait(float waitTime)
    {
        while (true)
        {
            float dist = Vector3.Distance(transform.position, target[0].transform.position);
            

            if (dist <= agent.stoppingDistance)
            {
                controller.animations = anims.Attack;
                target[0].SendMessage("TakeDamage", 10);
                GetComponent<AudioSource>().Play();
            }
            

            yield return new WaitForSeconds(waitTime);

        }
    }

    public void TakeDamage(int amount)
    {
        Debug.Log("Zombie took" + amount + " damage.");
        if (amount > 0)
        {
            health -= amount;
        }

        

        pSystem.SetActive(true);
        pSystem.GetComponentInChildren<ParticleSystem>().Play();
    }


  public void OnTriggerEnter(Collider other)
            {
          }
}
