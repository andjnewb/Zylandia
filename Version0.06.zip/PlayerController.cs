﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    // Start is called before the first frame update
    public float health = 100f;
    public GameObject player;
    public Texture texture;
    public AudioSource walk;
    public float interactDistance = 3.0f;
    public int playerCredits = 0;
    public GameObject canvas;

    void Start()
    {
        //camera = GetComponent<Camera>();
        
        
        //StartCoroutine(walkNoise());
    }

    // Update is called once per frame
    void Update()
    {
        if (health <= 0)
        {
            //Debug.Log("You have died!");
            //transform.position = new Vector3(0, 0, 0);
        }
        //Debug.Log(camera.transform.position);

        interactCheck();//Check a ray from the player to see if any interactable objects are in range
    }

    IEnumerator walkNoise()
    {
        while (true)
        {
            if (gameObject.GetComponent<Rigidbody>().velocity.x > 1.0f || gameObject.GetComponent<Rigidbody>().velocity.x < -1.0f
                || gameObject.GetComponent<Rigidbody>().velocity.z > 1.0f || gameObject.GetComponent<Rigidbody>().velocity.z < -1.0f)
            {
                walk.Play();

            }
            yield return new WaitForSeconds(0.5f);
        }
    }

    public void TakeDamage(int amount)
    {
        Debug.Log("I took" + amount + " damage.");
        if (amount > 0)
        {
            health -= amount;
        }

    }

    public void interactCheck()
    {
        //This functions checks a ray at the mouse's location. If it collides with something, it send an interact message to the object. If the object has such a function, it will execute it.

        RaycastHit info = new RaycastHit();
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        float distanceToInteractable = 0;

        if (Physics.Raycast(ray, out info))
        {
            //Draw ray from camera to mouse position
            Debug.DrawRay(GetComponentInChildren<Camera>().transform.position, GetComponentInChildren<Camera>().transform.forward, Color.red);
            //Debug.Log(info.collider.name);
            if (info.collider.transform.position != null && transform.position != null) { distanceToInteractable = Vector3.Distance(transform.position, info.collider.transform.position); }//Now that we have hit an object, let's check the distance
        }

        if (info.collider == null)
        { return; }

        //Debug.Log("Distance from player to object: " + distanceToInteractable);
        if (distanceToInteractable <= interactDistance)
        {
            if (info.collider.gameObject.GetComponent<PurchaseController>())
            {
                canvas.GetComponent<CanvasManager>().updateInteractText(info.collider.gameObject.GetComponent<PurchaseController>().InteractionText);
            }
            if (info.collider.gameObject.GetComponent<PurchaseController>().itemCost <= playerCredits)
            {
                canvas.GetComponent<CanvasManager>().interactTextColor(Color.green);

            }
            if (info.collider.gameObject.GetComponent<PurchaseController>().itemCost > playerCredits)
            {
                canvas.GetComponent<CanvasManager>().interactTextColor(Color.red);

            }
        }

        if (distanceToInteractable > interactDistance)
        {
            canvas.GetComponent<CanvasManager>().updateInteractText(" ");
            
            
        }



        if (Input.GetKeyDown(KeyCode.E))
        {
            if (distanceToInteractable <= interactDistance)
            {
                info.collider.SendMessageUpwards("interact", SendMessageOptions.DontRequireReceiver);

                //Doing things differently for purchasing. We need to to be able to get the cost of the item from the item, and check it against the player's available credits.
                if (info.collider.GetComponent<PurchaseController>())
                {
                    //Debug.Log(info.collider.GetComponent<PurchaseController>().itemCost);
                    Debug.Log(playerCredits);
                    if (info.collider.GetComponent<PurchaseController>().itemCost <= playerCredits)
                    {
                        info.collider.GetComponent<PurchaseController>().enableForPlayer();//enable the item or its effect for the player

                    }
                   

                }
            }
        }

        
    }

    

    public void OnTriggerEnter(Collider other)
    {
        //Debug.Log(other.name);


    }

}
