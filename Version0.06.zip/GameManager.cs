﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public int round;
    public int zombieCount;
    [SerializeField]
    public GameObject spawner;
    public Canvas ui;
    // Start is called before the first frame update
    void Start()
    {
        startNextRound();
    }

    // Update is called once per frame
    void Update()
    { 
        //Debug.Log(zombieCount + " zombies left!");

        if (zombieCount <= 0)
        {
            startNextRound();
        }

        //Let the canvas know it needs to increment the round text
        ui.BroadcastMessage("UpdateRound", round);

        if (Input.GetKey(KeyCode.Escape))
        {
            Application.Quit();
        }
    }



    void startNextRound()
    {
        
            round++;
            zombieCount = round * 2;
            //Let the SpawnZombie script attached to GameManager know it needs to spawn zombieCOunt zombies
            spawner.SendMessage("spawn", zombieCount);


    }
}
