﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace Kineractive
{
    [AddComponentMenu("KINERACTIVE/Inputs/Keycode Input")]
    public class KeycodeInput : KineractiveInput
    {
        [SerializeField] protected KeyCode keyCodeInput;


        public override void CheckForInput()
        {
            if (BypassInput)
                return;

            if (repeatingInput)
            {
                if (UnityEngine.Input.GetKey(keyCodeInput))
                    InputActivated();
            }
            else if (UnityEngine.Input.GetKeyDown(keyCodeInput))
                InputActivated();

            if (UnityEngine.Input.GetKeyUp(keyCodeInput) &&
                wasPressedDown)
                InputDeactivated();
        }


        protected override void InputActivated()
        {
            OnInput.Invoke();

            base.InputActivated();


            wasPressedDown = true;
        }

        protected override void InputDeactivated()
        {

            OnInputEnd.Invoke();

            base.InputDeactivated();

            wasPressedDown = false; 
        }
    }
}