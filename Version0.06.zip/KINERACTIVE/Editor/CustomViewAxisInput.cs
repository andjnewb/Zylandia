﻿using System;
using UnityEngine;
using UnityEditor;

/// <summary>
/// This script changes the Inpsector view for AxisInput to make the serialized Input field appear at the top of the script in the inspector
/// </summary>

namespace Kineractive
{
    [CustomEditor(typeof(AxisInput))]
    [CanEditMultipleObjects]
    public class CustomViewAxisInput : UnityEditor.Editor
    {
        SerializedProperty BypassInput;
        SerializedProperty axisInput;
        SerializedProperty repeatingInput;
        SerializedProperty axisPolarity; 
       
        SerializedProperty OnInput;

        SerializedProperty OnInputEnd;


        SerializedProperty axisInputString;


        protected string[] inputChoices;
        int inputChoiceIndex = 0;




        void OnEnable()
        {
            BypassInput = serializedObject.FindProperty("BypassInput");
            axisInput = serializedObject.FindProperty("axisInput");
            repeatingInput = serializedObject.FindProperty("repeatingInput");
            axisPolarity = serializedObject.FindProperty("axisPolarity");
            
            OnInput= serializedObject.FindProperty("OnInput");

            OnInputEnd = serializedObject.FindProperty("OnInputEnd");

            KineractiveManager iMan = FindObjectOfType<KineractiveManager>();
            if (iMan != null)
            {
                if (iMan.PlayerInputs != null)
                {
                    inputChoices = iMan.PlayerInputs.AxisInputs;
                }
                else
                {
                    inputChoices = new string[] { "No 'Player Inputs' set in Interactive Manager" };
                    Debug.LogWarning("'Player Inputs' field in Interactive Manager is empty. Please insert a Player Inputs scriptable object into the empty field.");
                }

             }
            else
            {
                inputChoices = new string[] { "Not Found: Interactive Manager" };

                Debug.LogWarning("Interactive Manager not found - Please add the Interactive Manager component to this scene");
            }



            axisInputString = serializedObject.FindProperty("axisInputString");
            inputChoiceIndex = Array.IndexOf(inputChoices, axisInputString.stringValue);


        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            CustomViewHelper.DisplayTitle("Axis Input", CustomViewHelper.IconTypes.AxisInput);
            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            CustomViewHelper.DisplayHeader("Input Type");


            inputChoiceIndex = EditorGUILayout.Popup("Axis Input", inputChoiceIndex, inputChoices);
            if (inputChoiceIndex < 0)
                inputChoiceIndex = 0;

            axisInputString.stringValue = inputChoices[inputChoiceIndex];

            EditorGUILayout.PropertyField(axisPolarity);
            EditorGUILayout.PropertyField(repeatingInput, new GUIContent("Repeating"));
            EditorGUILayout.EndVertical();

            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            EditorGUILayout.PropertyField(BypassInput, new GUIContent("Bypass", "Turn off this input? Manually here, or by script, or by event."));
            EditorGUILayout.EndVertical();

            

            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            CustomViewHelper.DisplayHeader("When Input Starts (Axis is not 0)");
            

            EditorGUILayout.PropertyField(OnInput, new GUIContent("On Input Start"));
            EditorGUILayout.EndVertical();

            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            CustomViewHelper.DisplayHeader("When Input Ends (Axis returns to 0)");
           

            EditorGUILayout.PropertyField(OnInputEnd, new GUIContent("On Input End"));
            EditorGUILayout.EndVertical();
     
            serializedObject.ApplyModifiedProperties();
        }
    }
}