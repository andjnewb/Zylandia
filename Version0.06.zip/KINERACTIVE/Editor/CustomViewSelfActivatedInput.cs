﻿using System;
using UnityEngine;
using UnityEditor;

namespace Kineractive
{
    [CustomEditor(typeof(SelfActivatedInput))]
    [CanEditMultipleObjects]
    public class CustomViewSelfActivatedInput : UnityEditor.Editor
    {


        SerializedProperty OnInput;

        SerializedProperty OnInputEnd;


        SerializedProperty BypassInput;

        SerializedProperty repeatingInput;


        void OnEnable()
        {
            BypassInput = serializedObject.FindProperty("BypassInput");

            repeatingInput = serializedObject.FindProperty("repeatingInput");


            OnInput = serializedObject.FindProperty("OnInput");

            OnInputEnd = serializedObject.FindProperty("OnInputEnd");

            KineractiveManager iMan = FindObjectOfType<KineractiveManager>();
            if (iMan != null)
            {
               
            }
            else
            {
                Debug.LogWarning("Interactive Manager not found - Please add the Interactive Manager component to this scene");
            }
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            CustomViewHelper.DisplayTitle("Self Activated Input", CustomViewHelper.IconTypes.SelfInput);

            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            EditorGUILayout.PropertyField(repeatingInput, new GUIContent("Repeating", "Keep repeating the OnInput event, while this component is active."));
            EditorGUILayout.EndVertical();

            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            EditorGUILayout.PropertyField(BypassInput, new GUIContent("Bypass", "Turn off this input? Manually here, or by script, or by event."));
            EditorGUILayout.EndVertical();
            

            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            CustomViewHelper.DisplayHeader("When Self Activated Input Starts");
            
            EditorGUILayout.PropertyField(OnInput, new GUIContent("On Input Start"));
            EditorGUILayout.EndVertical();

            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            CustomViewHelper.DisplayHeader("When Self Activated Input Ends");

            

            EditorGUILayout.PropertyField(OnInputEnd, new GUIContent("On Input End"));
            EditorGUILayout.EndVertical();

            serializedObject.ApplyModifiedProperties();
        }
    }
}
