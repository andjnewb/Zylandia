﻿using System;
using UnityEngine;
using UnityEditor;

/// <summary>
/// This script changes the Inpsector view for AxisInput to make the serialized Input field appear at the top of the script in the inspector
/// </summary>

namespace Kineractive
{
    [CustomEditor(typeof(AnalogInput))]
    [CanEditMultipleObjects]
    public class CustomViewAnalogInput : UnityEditor.Editor
    {
        SerializedProperty BypassInput;
        SerializedProperty axisInput;
        SerializedProperty repeatingInput;
        
        SerializedProperty OnInput;

        SerializedProperty OnInputEnd;


        SerializedProperty axisInputString;


        SerializedProperty sendFloat;
        SerializedProperty invertInput;

        protected string[] inputChoices;
        int inputChoiceIndex = 0;


        void OnEnable()
        {
            BypassInput = serializedObject.FindProperty("BypassInput");
            axisInput = serializedObject.FindProperty("axisInput");
            repeatingInput = serializedObject.FindProperty("repeatingInput");
            sendFloat = serializedObject.FindProperty("SendFloat");
           
            OnInput= serializedObject.FindProperty("OnInput");

            OnInputEnd = serializedObject.FindProperty("OnInputEnd");
            invertInput = serializedObject.FindProperty("invertInput");

            KineractiveManager iMan = FindObjectOfType<KineractiveManager>();
            if (iMan != null)
            {
                if (iMan.PlayerInputs != null)
                {
                    inputChoices = iMan.PlayerInputs.AxisInputs;
                }
                else
                {
                    inputChoices = new string[] { "No 'Player Inputs' set in Interactive Manager" };
                    Debug.LogWarning("'Player Inputs' field in Interactive Manager is empty. Please insert a Player Inputs scriptable object into the empty field.");
                }

            }
            else
            {
                inputChoices = new string[] { "Not Found: Interactive Manager" };

                Debug.LogWarning("Interactive Manager not found - Please add the Interactive Manager component to this scene");
            }



            axisInputString = serializedObject.FindProperty("axisInputString");
            inputChoiceIndex = Array.IndexOf(inputChoices, axisInputString.stringValue);

           

        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            CustomViewHelper.DisplayTitle("Analog Input", CustomViewHelper.IconTypes.AnalogInput);
            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            CustomViewHelper.DisplayHeader("Input Type");


            inputChoiceIndex = EditorGUILayout.Popup("Axis Input", inputChoiceIndex, inputChoices);
            if (inputChoiceIndex < 0)
                inputChoiceIndex = 0;

            axisInputString.stringValue = inputChoices[inputChoiceIndex];

            EditorGUILayout.PropertyField(invertInput);

            EditorGUILayout.EndVertical();

            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            EditorGUILayout.PropertyField(BypassInput, new GUIContent("Bypass", "Turn off this input? Manually here, or by script, or by event."));
            EditorGUILayout.EndVertical();

            
            

            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            CustomViewHelper.DisplayHeader("Analog Event");
            EditorGUILayout.PropertyField(sendFloat);
            EditorGUILayout.EndVertical();

            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            CustomViewHelper.DisplayHeader("When Input Starts (Axis is not 0)");
           

            EditorGUILayout.PropertyField(OnInput, new GUIContent("On Input Start"));
            EditorGUILayout.EndVertical();

            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            CustomViewHelper.DisplayHeader("When Input Ends (Axis is 0)");


            EditorGUILayout.PropertyField(OnInputEnd, new GUIContent("On Input End"));
            EditorGUILayout.EndVertical();
            

     
            serializedObject.ApplyModifiedProperties();
        }
    }
}