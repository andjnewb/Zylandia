﻿using System;
using UnityEngine;
using UnityEditor;

namespace Kineractive
{
    [CustomEditor(typeof(KeycodeInput))]
    [CanEditMultipleObjects]
    public class CustomViewKeyCodeInput : UnityEditor.Editor
    {
        SerializedProperty BypassInput;
        SerializedProperty keyCodeInput;
        SerializedProperty repeatingInput;
       

        SerializedProperty OnInput;

        SerializedProperty OnInputEnd;


  
        void OnEnable()
        {
            BypassInput = serializedObject.FindProperty("BypassInput");
            keyCodeInput = serializedObject.FindProperty("keyCodeInput");
            repeatingInput = serializedObject.FindProperty("repeatingInput");


            OnInput = serializedObject.FindProperty("OnInput");

            OnInputEnd = serializedObject.FindProperty("OnInputEnd");

            KineractiveManager iMan = FindObjectOfType<KineractiveManager>();
            if (iMan != null)
            {
            }
            else
            {

                Debug.LogWarning("Interactive Manager not found - Please add the Interactive Manager component to this scene");
            }


        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            CustomViewHelper.DisplayTitle("Key Code Input", CustomViewHelper.IconTypes.KeyCodeInput);
            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            CustomViewHelper.DisplayHeader("Input Type");
            EditorGUILayout.PropertyField(keyCodeInput);
            EditorGUILayout.PropertyField(repeatingInput, new GUIContent("Repeating"));
            EditorGUILayout.EndVertical();

            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            EditorGUILayout.PropertyField(BypassInput, new GUIContent("Bypass", "Turn off this input? Manually here, or by script, or by event."));
            EditorGUILayout.EndVertical();


  

            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            CustomViewHelper.DisplayHeader("When Input Starts");
           

            EditorGUILayout.PropertyField(OnInput, new  GUIContent("On Input Start"));
            EditorGUILayout.EndVertical();

            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            CustomViewHelper.DisplayHeader("When Input Ends");
           

            EditorGUILayout.PropertyField(OnInputEnd, new GUIContent("On Input End"));
            EditorGUILayout.EndVertical();

            serializedObject.ApplyModifiedProperties();
        }
    }
}