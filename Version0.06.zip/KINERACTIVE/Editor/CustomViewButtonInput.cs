﻿using System;
using UnityEngine;
using UnityEditor;

namespace Kineractive
{
    [CustomEditor(typeof(ButtonInput))]
    [CanEditMultipleObjects]
    public class CustomViewBinaryInput : UnityEditor.Editor
    {
        SerializedProperty BypassInput;

        SerializedProperty repeatingInput;


        SerializedProperty OnInput;

        SerializedProperty OnInputEnd;

        SerializedProperty buttonInputString;


        protected string[] inputChoices; 
        int inputChoiceIndex = 0;


        void OnEnable()
        {
            BypassInput = serializedObject.FindProperty("BypassInput");

            repeatingInput = serializedObject.FindProperty("repeatingInput");
        

            OnInput = serializedObject.FindProperty("OnInput");

            OnInputEnd = serializedObject.FindProperty("OnInputEnd");

            
            KineractiveManager iMan = FindObjectOfType<KineractiveManager>();
            if (iMan != null)
            {
                if (iMan.PlayerInputs != null)
                {
                    inputChoices = iMan.PlayerInputs.ButtonInputs;
                }
                else
                {
                    inputChoices = new string[] { "No 'Player Inputs' set in Interactive Manager" };
                    Debug.LogWarning("'Player Inputs' field in Interactive Manager is empty. Please insert a Player Inputs scriptable object into the empty field.");
                }


            }
            else
            {
                inputChoices = new string[] { "Not Found: Interactive Manager" };

                Debug.LogWarning("Interactive Manager not found - Please add the Interactive Manager component to this scene");
            }

                

            buttonInputString = serializedObject.FindProperty("buttonInputString");
            inputChoiceIndex = Array.IndexOf(inputChoices, buttonInputString.stringValue);



        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();



            CustomViewHelper.DisplayTitle("Button Input", CustomViewHelper.IconTypes.ButtonInput);
            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);

            CustomViewHelper.DisplayHeader("Input Type");

            inputChoiceIndex = EditorGUILayout.Popup("Button Input", inputChoiceIndex, inputChoices);
            if (inputChoiceIndex < 0)
                inputChoiceIndex = 0;

            buttonInputString.stringValue = inputChoices[inputChoiceIndex];
            EditorGUILayout.PropertyField(repeatingInput, new GUIContent("Repeating Input", ""));

            EditorGUILayout.EndVertical();

            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            EditorGUILayout.PropertyField(BypassInput, new GUIContent("Bypass", "Turn off this input? Manually here, or by script, or by event."));
            EditorGUILayout.EndVertical();


            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            CustomViewHelper.DisplayHeader("When Input Starts (Button Is Down / Pushed)");
   


            EditorGUILayout.PropertyField(OnInput, new GUIContent("On Input Start"));
            EditorGUILayout.EndVertical();

            EditorGUILayout.BeginVertical(CustomViewHelper.BodyBG);
            CustomViewHelper.DisplayHeader("When Input Ends (Button Is Up / Released)");
            

            EditorGUILayout.PropertyField(OnInputEnd, new GUIContent("On Input End"));
            EditorGUILayout.EndVertical();

            serializedObject.ApplyModifiedProperties();
        }
    }
}