﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CanvasManager : MonoBehaviour
{
    private Text roundText;
    private Text healthText;
    private Text creditText;
    private Text context;

    public GameObject[] itemContexts;//Uses item ids


    public GameObject player;

    // Start is called before the first frame update
    void Start()
    {
        roundCounterSetup();
        healthCounterSetup();
        creditCounterSetup();
        interactTextSetup();
    }
    // Update is called once per frame
    void Update()
    {
        updateHealth();//updates the health counter
        updateCredits();//updates the credits counter
    }

    public void interactTextSetup()
    {
        Font arial;
        arial = (Font)Resources.GetBuiltinResource(typeof(Font), "Arial.ttf");

        GameObject textGO = new GameObject();
        textGO.transform.parent = gameObject.transform;
        textGO.AddComponent<Text>();


        context = textGO.GetComponent<Text>();
        context.font = arial;
        context.text = " ";
        context.color = Color.red;
        context.fontSize = 48;
        context.alignment = TextAnchor.MiddleCenter;

        RectTransform rectTransform;
        rectTransform = context.GetComponent<RectTransform>();
        rectTransform.localPosition = new Vector3(0, -200, 0);
        rectTransform.sizeDelta = new Vector2(600, 200);
    }

    public void interactTextColor(Color color)
    {
        context.color = color;
    }

    public void updateInteractText(string text)
    {
        
        context.text = text;
    }

    void UpdateRound(int round)
    {
        roundText.text = "Round " + round.ToString();
    }

    void updateHealth()
    {
        healthText.text = player.GetComponent<PlayerController>().health.ToString();
    }

    void updateCredits()
    {
        creditText.text = "Cr: " + player.GetComponent<PlayerController>().playerCredits.ToString();
    }

    void roundCounterSetup()
    {
        Font arial;
        arial = (Font)Resources.GetBuiltinResource(typeof(Font), "Arial.ttf");

        GameObject textGO = new GameObject();
        textGO.transform.parent = gameObject.transform;
        textGO.AddComponent<Text>();


        roundText = textGO.GetComponent<Text>();
        roundText.font = arial;
        roundText.text = "Round 1";
        roundText.color = Color.red;
        roundText.fontSize = 48;
        roundText.alignment = TextAnchor.LowerRight;

        RectTransform rectTransform;
        rectTransform = roundText.GetComponent<RectTransform>();
        rectTransform.localPosition = new Vector3(350, -200, 0);
        rectTransform.sizeDelta = new Vector2(600, 200);
    }

    void creditCounterSetup()
    {
        Font arial;
        arial = (Font)Resources.GetBuiltinResource(typeof(Font), "Arial.ttf");

        GameObject textGO = new GameObject();
        textGO.transform.parent = gameObject.transform;
        textGO.AddComponent<Text>();


        creditText = textGO.GetComponent<Text>();
        creditText.font = arial;
        creditText.text = "Cr: " + player.GetComponent<PlayerController>().playerCredits.ToString();
        creditText.color = Color.green;
        creditText.fontSize = 48;
        creditText.alignment = TextAnchor.MiddleRight;

        RectTransform rectTransform;
        rectTransform = creditText.GetComponent<RectTransform>();
        rectTransform.localPosition = new Vector3(350, -200, 0);
        rectTransform.sizeDelta = new Vector2(600, 200);
    }


    void healthCounterSetup()
    {
        Font arial;
        arial = (Font)Resources.GetBuiltinResource(typeof(Font), "Arial.ttf");

        GameObject textGO = new GameObject();
        textGO.transform.parent = gameObject.transform;
        textGO.AddComponent<Text>();


        healthText = textGO.GetComponent<Text>();
        healthText.font = arial;
        healthText.text = "Health: " + player.GetComponent<PlayerController>().health.ToString();
        healthText.color = Color.red;
        healthText.fontSize = 48;
        healthText.alignment = TextAnchor.LowerLeft;

        RectTransform rectTransform;
        rectTransform = healthText.GetComponent<RectTransform>();
        rectTransform.localPosition = new Vector3(-350, -200, 0);//200, -125, 0
        rectTransform.sizeDelta = new Vector2(600, 200);
    }

}  