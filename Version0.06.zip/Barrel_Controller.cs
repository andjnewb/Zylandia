﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Barrel_Controller : MonoBehaviour
{
    public Camera cam;
    RaycastHit hitInfo;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame

    public void Update()
    {
        Vector2 centerScreen = new Vector3(Screen.width / 2, Screen.height / 2);
        Ray ray = cam.ScreenPointToRay(centerScreen);

        Physics.Raycast(ray, out hitInfo);

        transform.LookAt(hitInfo.point);

    }

}
